'''
This is our main driver file> it will be responsible for handling user input and displaying the current game state object.
'''

import pygame as p
import chessengine, random_move
p.display.set_caption('Chess')
p.display.set_icon(p.image.load('chess/images-20250415T085406Z-001/images/wK.png'))

WIDTH = HEIGHT = 512 #400 is other option
DIMENSION =  8 #dimension of a chess board are 8*8
SQ_SIZE = HEIGHT//DIMENSION #size of each square on the board
MAX_FPS = 15 #for animations
IMAGES = {}
board_type_global = "grey"

'''
Initialize a global dictionary of images. This will be called exactly once in the main.
'''
def load_images():
    # IMAGES['wp'] = p.image.load('project\chess\images-20250415T085406Z-001\images\wp.png')
    # IMAGES['bp'] = p.image.load('project\chess\images-20250415T085406Z-001\images/bp.png')
    pieces = ['wp', 'wR', 'wN', 'wB', 'wQ', 'wK', 'bp', 'bR', 'bN', 'bB', 'bQ', 'bK']
    for piece in pieces:
        IMAGES[piece] = p.image.load('chess/images-20250415T085406Z-001/images/'+ piece +'.png')    #Note: we can access an image by saying 'IMAGES['wp']'

'''
The main driver for our code. THis will handle user input and updating the graphics.
'''
whitepoint = 0
blackpoint = 0
def main(screen=None, board_type="grey"):
    p.init()
    
    if screen is None:
        screen = p.display.set_mode((WIDTH, HEIGHT))
    clock = p.time.Clock()
    screen.fill(p.Color('white'))
    gs = chessengine.GameState()
    global whitepoint,blackpoint,board_color,board_type_global
    board_type_global=board_type
    
    validMoves = gs.getValidMoves()
    moveMade = False #flag variable for when a move is made
    animate = False     #flag variable for when we should animate a move
    
    load_images() #only do this once, before the while loop
    running = True 
    sqSelected = () # no square is selected, keep track of the last click of the user
     
    playerClicks = [] #keep track o f player clicks (two tuples: [()])
    gameOver =  False
    playerOne = True #if a human is playing white, then this will be true
    playerTwo = True#Same as above but for black
    
    drawBoard(screen, board_type_global)
    drawGamestate(screen, gs, validMoves, sqSelected, board_type_global)
    
    

    


    
    
    
    while running:
        humanTurn = (gs.whiteToMove and playerOne) or (not gs.whiteToMove and playerTwo)
        for e in p.event.get():
            if e.type == p.QUIT:
                running = False
            #mouse handler
            elif e.type == p.MOUSEBUTTONDOWN: #if the mouse is clicked
                if not gameOver and humanTurn:
                    location = p.mouse.get_pos() #(x,y) position of the mouse
                    col = location[0]//SQ_SIZE #column of the square clicked
                    row = location[1]//SQ_SIZE #row of the square clicked

                    if sqSelected == (row , col):  # if the square clicked is the same as the last square clicked
                        sqSelected = ()  # deselect the square
                        playerClicks = []
                    else:
                        sqSelected = (row , col)  # update the square selected
                        playerClicks.append(sqSelected)  # add the square clicked to the list of player clicks
                        if len(playerClicks) == 2:  # after 2nd click
                            move = chessengine.Move(playerClicks[0], playerClicks[1], gs.board)
                            print(move.getChessNotation())  # print the move in chess notation
                            for i in range(len(validMoves)):
                                if move == validMoves[i]:
                                    gs.makeMove(validMoves[i])
                                    moveMade = True
                                    animate =True
                                    break
                            sqSelected = ()
                            playerClicks = []
                        if not moveMade and len(playerClicks) == 1:
                            playerClicks = [sqSelected]
            #key handlers
            elif e.type == p.KEYDOWN:
                if e.key == p.K_z: #undo when key is pressed z
                    gs.undoMove()
                    moveMade = True
                    animate = False      
                if e.key == p.K_r:  #reset the board whten 'r' is pressed
                    gs = chessengine.GameState()
                    validMoves = gs.getValidMoves()
                    sqSelected = ()
                    playerClicks = []
                    animate = False
           
        #AI move finder
        if not gameOver and not humanTurn:
            randommoves= random_move.findRandomMove(validMoves)
            gs.makeMove(randommoves)
            moveMade = True
            animate = True
            
                 
                    
        if moveMade:
            if animate:
                animateMoves(gs.movelog[-1], screen, gs.board, clock,board_type)
            validMoves = gs.getValidMoves()
            moveMade = False
        
        if board_type=="grey":
            # board_color=[p.Color('white'),p.Color('grey')]
            screen.fill(p.Color('white'))
        elif board_type=="green":
            screen.fill(p.Color('white'))            
        drawGamestate(screen,gs, validMoves, sqSelected,board_type)
        if gs.checkMate:
            gameOver = True 
            if gs.whiteToMove:
                 drawText(screen, 'Black Wins by Checkmate')
            else:
                drawText(screen, 'White Wins by Checkmate')
        elif gs.stalemate:
            gameOver=True
            drawText(screen, 'Stalemate')
        p.display.update() 
        clock.tick (MAX_FPS)
        p.display.flip()
        #     if gs.whiteToMove:
        #         drawText(screen, 'Black Wins by Checkmate')
        #         with open("history.txt","w") as file:
        #             file.writelines("White 0 --- Black 1 \n")
        #             file.close()
        #     else:
        #         drawText(screen, 'White Wins by Checkmate')
        #         with open("history.txt","w") as file:
        #             file.writelines("White 1 --- Black 0 \n")
        #             file.close()
        # elif gs.stalemate:
        #     gameOver=True
        #     drawText(screen, 'Stalemate')
        #     with open("history.txt","w") as file:
        #         file.writelines("White 0.5 --- Black 0.5 \n")
        #         file.close()
    if gs.stalemate:
        if gs.whiteToMove:
            with open("history.txt","a") as file:
                file.writelines("White 0.5 --- Black 0.5 \n")
                file.close()
        else:
            with open("history.txt","a") as file:
                file.writelines("White 0.5 --- Black 0.5 \n")
                file.close()
    elif gameOver:
        if gs.whiteToMove:
                with open("history.txt","a") as file:
                    file.writelines("White 0 --- Black 1 \n")
                    file.close()
        else:
                with open("history.txt","a") as file:
                    file.writelines("White 1 --- Black 0 \n")
                    file.close()
    
    
        
        
        
        
        
'''
Highlight the square selected and moves for piece selected
'''
def highlightSquares(screen, gs, validMoves, sqSelected):
    if sqSelected!=():
        r, c = sqSelected
        if gs.board[r][c][0] == ('w' if gs.whiteToMove else 'b'):   #sqSelected is a piece that can be moved
            #highlight selected square
            s= p.Surface((SQ_SIZE,SQ_SIZE))
            s.set_alpha(100)    #transperancy value -> 0 transparent; 255 opaque
            s.fill(p.Color('blue'))
            screen.blit(s, (c*SQ_SIZE, r*SQ_SIZE))
            #highlight moves from that square
            s.fill(p.Color('yellow'))
            for move in validMoves:
                if move.startRow == r and move.startCol == c:
                    screen.blit(s, (move.endCol*SQ_SIZE, move.endRow*SQ_SIZE))
                    
'''
winning and losing
'''  
# def score(gs):
#     whitepoint =0
#     blackpoint =0
#     gs = chessengine.GameState()
#     if gs.checkMate:
#             gameOver = True 
#             if gs.whiteToMove:
#                 whitepoint= 1
#                 blackpoint =0
#                 with open("history.txt","w") as file:
#                     file.writelines(f"White {whitepoint} --- Black {blackpoint}")
#             else:
#                 blackpoint=1
#                 blackpoint=0
#                 with open("history.txt","w") as file:
#                     file.writelines(f"White {whitepoint} --- Black {blackpoint}")
#     elif gs.stalemate:
#         gameOver=True
#         whitepoint=0.5
#         blackpoint=0.5
#         with open("history.txt","w") as file:
#             file.writelines(f"White {whitepoint} --- Black {blackpoint}")
    
        
        


'''
responsible all the graphics within the current GameState.board
'''
        
def drawGamestate(screen,gs, validMoves, sqSelected,board_type):
    drawBoard(screen, gs.board) #draw squares on the board
    drawBoard(screen, board_type)
    highlightSquares(screen, gs, validMoves, sqSelected) 
    drawPieces(screen,gs.board) #draw pieces on the board
    
    
    
'''
draw the squares on the board. The top left square is always light.
'''  
def drawBoard(screen,board_type):
   
    if board_type == "Blue":
        colors = [p.Color("white"), p.Color("aquamarine")]
    elif board_type == "Green":
        colors = [p.Color("white"), p.Color("chartreuse3")]
    elif board_type == "Red":
        colors = [p.Color("white"), p.Color("coral")]
    elif board_type == "Classic":
        colors = [p.Color("white"), p.Color("gray")]
    else:
        colors = [p.Color("white"), p.Color("gray")]

    for r in range(DIMENSION):
        for c in range(DIMENSION):
            color = colors[(r + c) % 2]
            p.draw.rect(screen, color, p.Rect(c * SQ_SIZE, r * SQ_SIZE, SQ_SIZE, SQ_SIZE))
          
    
'''
draw the pieces on the board using the current 
'''
def drawPieces(screen,board):
    for r in range(DIMENSION):
        for c in range(DIMENSION):
            piece = board[r][c] #get the piece at the current square
            if piece != '--': #if there is a piece at the current square
                screen.blit(IMAGES[piece], p.Rect(c*SQ_SIZE, r*SQ_SIZE, SQ_SIZE, SQ_SIZE))

'''
animating the moves
'''
# def animateMoves(move, screen, board, clock):
#     global board_type
#     dR = move.endRow - move.startRow
#     dC = move.endCol - move.startCol
#     framesPerSquare = 10  #frames to move one square
#     frameCount = (abs(dR) + abs(dC)) * framesPerSquare
#     global board_color
    
#     for frame in range(frameCount +1):
#         global color
#         r, c = (move.startRow + dR*frame/frameCount, move.startCol + dC*frame/frameCount)
#         drawBoard(screen, board)
#         drawPieces(screen, board)
#         #erase the piece moveed from its ending square
#         color = board_color[(move.endRow + move.endCol)%2]
#         endSquare = p.Rect(move.endCol*SQ_SIZE, move.endRow*SQ_SIZE, SQ_SIZE, SQ_SIZE)
#         p.draw.rect(screen,color, endSquare)
#         #draw captured piece onto rectangle
#         if move.pieceCaptured != '--':
#             screen.blit(IMAGES[move.pieceCaptured], endSquare)
#         #draw moving piece
#         screen.blit(IMAGES[move.pieceMoved], p.Rect(c*SQ_SIZE, r*SQ_SIZE, SQ_SIZE, SQ_SIZE))  
#         p.display.flip() 
#         clock.tick(60)
def animateMoves(move, screen, board, clock, board_type):
    dR = move.endRow - move.startRow
    dC = move.endCol - move.startCol
    framesPerSquare = 10
    frameCount = (abs(dR) + abs(dC)) * framesPerSquare

    for frame in range(frameCount + 1):
        r = move.startRow + dR * frame / frameCount
        c = move.startCol + dC * frame / frameCount
        drawBoard(screen, board_type)
        drawPieces(screen, board)
        end_square = p.Rect(move.endCol * SQ_SIZE, move.endRow * SQ_SIZE, SQ_SIZE, SQ_SIZE)
        piece = IMAGES[move.pieceMoved]
        
        
        color = p.Color("white") if (move.endRow + move.endCol) % 2 == 0 else p.Color("gray")
        if board_type == "Blue":
            color = p.Color("white") if (move.endRow + move.endCol) % 2 == 0 else p.Color("royalblue4")
        elif board_type == "Green":
            color = p.Color("white") if (move.endRow + move.endCol) % 2 == 0 else p.Color("seagreen")
        elif board_type == "Red":
            color = p.Color("white") if (move.endRow + move.endCol) % 2 == 0 else p.Color("firebrick")
        #animate  moving to blank square
        p.draw.rect(screen, color, end_square)
        screen.blit(piece, p.Rect(c * SQ_SIZE, r * SQ_SIZE, SQ_SIZE, SQ_SIZE))
        
        # Remove captured piece
        if move.pieceCaptured != "--" and (frame != frameCount):
            endSquare = p.Rect(move.endCol*SQ_SIZE, move.endRow*SQ_SIZE, SQ_SIZE, SQ_SIZE)
            p.draw.rect(screen,color, endSquare)
            #draw captured piece onto rectangle
            screen.blit(IMAGES[move.pieceCaptured], endSquare)
            p.draw.rect(screen, color, end_square)
            # Draw the moving piece
            piece = IMAGES[move.pieceMoved]
            screen.blit(piece, p.Rect(c * SQ_SIZE, r * SQ_SIZE, SQ_SIZE, SQ_SIZE))
        

        p.display.flip()
        clock.tick(60)


        
        
        
def drawText(screen, text):
    font = p.font.SysFont("Helvitca", 32, True, False)
    textObject = font.render(text, 0, p.Color('Grey'))
    textLocation = p.Rect(0, 0, WIDTH, HEIGHT).move(WIDTH/2 - textObject.get_width()/2, HEIGHT/2 - textObject.get_height()/2 )
    screen.blit(textObject, textLocation)
    textObject = font.render(text, 0, p.Color("Black"))
    screen.blit(textObject, textLocation.move(2, 2))
    
        
            
if __name__=='__main__':    #if this file is being run directly, then run the main function      
    main()
    
