'''
This class is responsible for storing all the information about the current state of a chess game.It will also be responsible for determining the valid moves at the current state. It will also keep a move log.
'''

class GameState():
    def __init__(self):
        #board is 8x8 2d list, each element of the list has 2 characters
        #the first character represents the colour of the place, 'b' or 'w'
        #the second character represents the type of the piece,'K' 'Q' 'R' 'B' 'N'
        #'--' represents the empty space with no piece
        self.board = [
            ["bR","bN","bB","bQ","bK","bB","bN","bR"],
            ["bp","bp","bp","bp","bp","bp","bp","bp"],
            ["--","--","--","--","--","--","--","--"],
            ["--","--","--","--","--","--","--","--"],
            ["--","--","--","--","--","--","--","--"],
            ["--","--","--","--","--","--","--","--"],
            ["wp","wp","wp","wp","wp","wp","wp","wp"],
            ["wR","wN","wB","wQ","wK","wB","wN","wR"]]
        # self.board = [
        #     ["--","--","--","--","--","--","--","bK"],
        #     ["--","--","--","--","--","--","--","wp"],
        #     ["--","--","--","--","--","--","--","wK"],
        #     ["--","--","--","--","--","wB","--","--"],
        #     ["--","--","--","--","--","--","--","--"],
        #     ["--","--","--","--","--","--","--","--"],
        #     ["--","--","--","--","--","--","--","--"],
        #     ["--","--","--","--","--","--","--","--"]]
        # self.board = [
        #     ["--","--","--","--","--","--","--","bK"],
        #     ["--","--","--","--","--","--","--","wp"],
        #     ["--","--","--","--","--","--","--","--"],
        #     ["--","--","--","--","--","--","--","wK"],
        #     ["--","--","--","--","--","--","--","--"],
        #     ["--","--","--","--","--","--","--","--"],
        #     ["--","--","--","--","--","--","--","--"],
        #     ["--","--","--","--","--","--","--","--"]]
        # self.board = [
        #     ["--","--","--","--","--","--","--","--"],
        #     ["--","--","--","--","--","--","--","--"],
        #     ["--","--","--","--","--","--","--","--"],
        #     ["--","--","--","--","--","--","--","--"],
        #     ["--","--","--","--","--","--","--","--"],
        #     ["--","--","--","--","--","--","--","--"],
        #     ["wp","wp","wp","wp","wp","wp","wp","wp"],
        #     ["wR","wN","wB","wQ","wK","wB","wN","wR"]]
        self.moveFunctions = {'p' : self.getPawnMoves, 'R': self.getRookMoves, 'N': self.getKnightMoves, 'B': self.getBishopMoves,
                              'Q': self.getQueenMoves, 'K': self.getKingMoves}
        self.whiteToMove = True
        self.movelog = []
        self.whiteKingLocation = (7, 4)
        self.blackKingLocation = (0, 4)
        self.checkMate = False
        self.stalemate = False       
        self.enpassantPossible = () #coordinate for the square  where en passant capture is possible
        self.currentCastlingRight = CastleRight(True, True, True, True)
        self.castleRightLog = [CastleRight(self.currentCastlingRight.wks, self.currentCastlingRight.bks,
                                           self.currentCastlingRight.wqs, self.currentCastlingRight.bqs)]
        
        
    '''
    Takes a move as a parameter and executes it (not work for castling, pawn promotion, and en-passant)
    '''

    def makeMove(self, move):
        self.board[move.startRow][move.startCol] = '--'  #empty square
        self.board[move.endRow][move.endCol] = move.pieceMoved #move piece to new square
        self.movelog.append(move) #add move to the move log, also log the move so we can undo it later
        self.whiteToMove = not self.whiteToMove #switch turns
        #self.whiteToMove = True if self.whiteToMove == False else False #switch turns
        #update the king location if moved
        if move.pieceMoved == "wK":
            self.whiteKingLocation = (move.endRow, move.endCol)
        elif move.pieceMoved == "bK":
            self.blackKingLocation = (move.endRow, move.endCol)
            
        #pawn promotion
        if move.isPawnPromotion:
            self.board[move.endRow][move.endCol] = move.pieceMoved[0] + 'Q'
        
        #enpassant move
        if move.isEnpassantMove:
            self.board[move.startRow][move.endCol] = '--' #capturing
        
        #update enpassantPossible variable
        if move.pieceMoved[1] =='p' and abs(move.startRow - move.endRow) ==2: #only on 2 square pawn advance
            self.enpassantPossible = ((move.startRow + move.endRow)//2, move.startCol)
        else:
            self.enpassantPossible = ()  
            
        #castle move
        if move.isCastleMove:
           if move.endCol -move.startCol == 2:   #king side castle
               self.board[move.endRow][move.endCol-1] = self.board[move.endRow][move.endCol+1]
               self.board[move.endRow][move.endCol+1] = '--' #erase old rook
           else:    #queenside castle move
               self.board[move.endRow][move.endCol+1] = self.board[move.endRow][move.endCol-2]  #move the rook             
               self.board[move.endRow][move.endCol-2] ='--'
        
            
        #update castling rights-whenever it is a rook or a king move
        self.updateCastleRights(move)
        self.castleRightLog.append(CastleRight(self.currentCastlingRight.wks, self.currentCastlingRight.bks,
                                                self.currentCastlingRight.wqs, self.currentCastlingRight.bqs))
        
        
    '''
    Undo the last move made
    '''
    def undoMove(self):
        if len(self.movelog) != 0: #make sure there is a move to undo
            move = self.movelog.pop()
            self.board[move.startRow][move.startCol] = move.pieceMoved
            self.board[move.endRow][move.endCol] = move.pieceCaptured 
            self.whiteToMove = not self.whiteToMove # switch turns back 
            
            
            #update the king move
            if move.pieceMoved == "wK":
                self.whiteKingLocation = (move.startRow, move.startCol)
            elif move.pieceMoved == "bK":
                self.blackKingLocation = (move.startRow, move.startCol)
                
                
            #undo the enpassant move
            if move.isEnpassantMove:
                self.board[move.endRow][move.endCol] = '--' #leave landing square blank
                self.board[move.startRow][move.endCol] = move.pieceCaptured
                self.enpassantPossible = (move.startRow, move.endCol)
                
                
            #undo the 2 square pawn advance
            if move.pieceMoved[1] == 'p' and  abs(move.startRow - move.endRow) ==2:
                self.enpassantPossible = ()
                
            #undo the castle rights
            self.castleRightLog.pop()   #get rid of new castle rights from the move we are undoing
            newRights = self.castleRightLog[-1]
            self.currentCastlingRight = CastleRight(newRights.wks, newRights.bks, newRights.wqs, newRights.bqs) #set the current castle rights to the last one in the list
            #undo castle move
            if move.isCastleMove:
                if move.endCol - move.startCol == 2:    #king side
                    self.board[move.endRow][move.endCol+1] = self.board[move.endRow][move.endCol-1]
                    self.board[move.endRow][move.endCol-1]='--'
                else:   #queenside
                    self.board[move.endRow][move.endCol-2]=self.board[move.endRow][move.endCol+1]
                    self.board[move.endRow][move.endCol+1]='--' 
            
            
                
    '''
    
    '''
    def updateCastleRights(self, move):
        if move.pieceMoved == 'wK':
            self.currentCastlingRight.wks = False
            self.currentCastlingRight.wqs = False    
        elif move.pieceMoved == 'bK':
            self.currentCastlingRight.bks = False
            self.currentCastlingRight.bqs = False
        elif move.pieceMoved == 'wR':
            if move.startRow == 7:
                if move.startCol == 0: #left rook
                    self.currentCastlingRight.wqs = False
                elif move.startCol == 7: #right rook
                    self.currentCastlingRight.wks = False
        elif move.pieceMoved == 'bR':
            if move.startRow == 0:
                if move.startCol == 0: #left rook
                    self.currentCastlingRight.bqs = False
                elif move.startCol == 7: #right rook
                    self.currentCastlingRight.bks = False
        
    
    
    '''
    all moves considering checks
    '''
    def getValidMoves(self):
        for log in self.castleRightLog:
            print(log.wks, log.wqs, log.bks, log.bqs, end=", ")
        print()
        tempEnpassantPossible = self.enpassantPossible
        tempCastleRights = CastleRight(self.currentCastlingRight.wks, self.currentCastlingRight.bks,
                                       self.currentCastlingRight.wqs, self.currentCastlingRight.wks)    #copy the current castle rights
        #generate all possible moves
        moves = self.getAllPossibleMoves()
        if self.whiteToMove:
            self.getCastleMoves(self.whiteKingLocation[0], self.whiteKingLocation[1], moves)
        else:
            self.getCastleMoves(self.blackKingLocation[0], self.blackKingLocation[1], moves)
        #for each move, make the move
        for i in range(len(moves)-1, -1, -1):   #when removing from a list go bakcwards through that list
            self.makeMove(moves[i])
            # genarate all opponent moves
            oppMoves = self.getAllPossibleMoves()
            #for each of yuor opponents moves, see if they attack your king
            self.whiteToMove = not self.whiteToMove
            if self.inCheck():
                moves.remove(moves[i])  #if they do attack the king, not a valid move
            self.whiteToMove = not self.whiteToMove
            self.undoMove()
        if self.whiteToMove:
            if len(moves) == 0:     #either checkmate or stealmate
                if self.inCheck():
                    self.checkMate = True
                if not self.inCheck():
                    self.stalemate = True
        else:
            if len(moves) == 0:     #either checkmate or stealmate
                if self.inCheck():
                    self.checkMate = True
                if not self.inCheck():
                    self.stalemate = True
        self.enpassantPossible = tempEnpassantPossible
        self.currentCastlingRight = tempCastleRights
        return moves
        
    #determine the current player is in check       
    def inCheck(self):
        if self.whiteToMove:
            return self.squareUnderAttack(self.whiteKingLocation[0], self.whiteKingLocation[1])
        else:
            return self.squareUnderAttack(self.blackKingLocation[0], self.blackKingLocation[1])
      
    #determine if the enemy can attack the square  
    def squareUnderAttack(self, r, c):
        self.whiteToMove = not self.whiteToMove #switch to opponent pov
        oppMoves = self.getAllPossibleMoves() 
        self.whiteToMove = not self.whiteToMove     #switch turn back
        for move in oppMoves:
            if move.endRow == r and move.endCol == c:  #square is under attack
                return True
        return False
            
    '''
    all moves without considering checks
    '''
    def getAllPossibleMoves(self):
        moves = []
        for r in range(len(self.board)): #number of rows
            for c in range(len(self.board[r])): #number of cols in given row
                turn = self.board[r][c][0]
                if (turn == 'w' and self.whiteToMove) or (turn == 'b' and not self.whiteToMove):
                    piece = self.board[r][c][1]
                    if piece.lower() == 'p':
                        piece = 'p'
                    self.moveFunctions[piece](r, c, moves)  #calls the appropiate move forms
        return moves
        
                        
    '''
    Get all the pawn moves for the pawn located  at row, col and add these moves to the list
    '''
    
    def getPawnMoves(self, r, c, moves):
        if self.whiteToMove: #white pawn move
            if self.board[r-1][c] == '--': #for the square pawn advance
                moves.append(Move((r, c), (r-1,c), self.board))
                if r == 6 and self.board[r-2][c] == '--': #2 square pawn advance
                    moves.append(Move((r, c), (r-2, c), self.board))
            if c-1 >= 0: #capture to the left
                if self.board[r-1][c-1][0] == 'b' and self.board[r-1][c-1] != 'b':      #a piece to capture
                    moves.append(Move((r, c), (r-1, c-1), self.board))
                elif (r-1, c-1) == self.enpassantPossible:
                     moves.append(Move((r, c), (r-1, c-1), self.board, isenpassantmove=True))
            if c+1 <= 7: #capture to the right
                if self.board[r-1][c+1][0] == 'b' and self.board[r-1][c+1] != 'b':      #a piece to capture
                    moves.append(Move((r, c), (r-1, c+1), self.board))
                elif (r-1, c+1)==self.enpassantPossible:
                    moves.append(Move((r,c), (r-1, c+1), self.board, isenpassantmove=True))
        else:   #black pawn moves
            if self.board[r+1][c] == '--':
                moves.append(Move((r, c), (r+1, c), self.board))
                if r == 1 and self.board[r+2][c] == '--':
                    moves.append(Move((r, c), (r+2, c), self.board))
            if  c-1 >= 0:
                if self.board[r+1][c-1][0] == 'w' and self.board[r+1][c-1] != 'w':
                    moves.append(Move((r, c), (r+1, c-1), self.board))
                elif (r+1, c-1) == self.enpassantPossible:
                    moves.append(Move((r, c), (r+1, c-1), self.board, isenpassantmove=True))
            if c+1 <= 7:
                if self.board[r+1][c+1][0] == 'w' and self.board[r+1][c+1] != 'w':
                    moves.append(Move((r, c), (r+1, c+1), self.board)) 
                elif (r+1,  c+1) == self.enpassantPossible:
                    moves.append(Move((r, c), (r+1, c+1), self.board, isenpassantmove=True)) 
    
    '''
    get all the rook moves for the rook located at row , col and add these moves to the list
    '''
    def getRookMoves(self, r, c, moves):
        directions = ((-1,0), (0, -1), (1, 0), (0, 1))  #up, left, down, right
        enemyColor = 'b' if self.whiteToMove else 'w'
        for d in directions:
            for i in range(1, 8):
                endRow = r + d[0] * i
                endCol = c + d[1] * i 
                if 0 <= endRow < 8 and 0 <= endCol < 8:
                    endPiece = self.board[endRow][endCol]
                    if endPiece == '--':    #empty space valid
                        moves.append(Move((r,c), (endRow, endCol), self.board))    
                    elif endPiece[0] == enemyColor:     #enemy piece valid
                        moves.append(Move((r, c), (endRow, endCol), self.board))
                        break
                    else:   #friendly piece invalid
                        break
                else: #off board
                    break
        
            
    
    '''
    get all the Knight moves for the rook located at row , col and add these moves to the list
    '''
    def getKnightMoves(self, r, c, moves):
        directions = ((-2, -1), (-2, 1), (2, 1), (2, -1), (-1, -2), (1, -2), (-1, 2), (1, 2))
        enemyColor = 'b' if self.whiteToMove else 'w'
        for d in directions:
            for i in range(1, 8):
                endRow = r + d[0] 
                endCol = c + d[1] 
                if 0 <= endRow < 8 and 0 <= endCol < 8: #onBoard
                    endPiece = self.board[endRow][endCol]
                    if endPiece == '--' or endPiece[0] == enemyColor:
                        moves.append(Move((r, c), (endRow, endCol), self.board))
                    elif endPiece[0] == enemyColor:
                        moves.append(Move((r, c), (endRow, endCol), self.board))
                        break
                        break
                    else:
                        break
                else:
                    break
    '''
    def getKnightMoves(self, r, c, moves):
        directions = ((-2, -1), (-2, 1), (2, 1), (2, -1), (-1, -2), (1, -2), (-1, 2), (1, 2))
        allyColor = 'w' if self.whiteToMove else 'b'
        for d in directions:
            endRow = r + d[0]
            endCol = c + d[1]
            if 0 <= endRow < 8 and 0 <= endCol < 8:
                endPiece = self.board[endRow][endCol]
                if endPiece[0] != allyColor:
                    moves.append(Move((r,c), (endRow, endCol), self.board))
    '''              
        
    
    '''
    get all the Bishop moves for the rook located at row , col and add these moves to the list
    '''
    def getBishopMoves(self, r, c, moves):
        directions = ((1, 1), (-1, 1), (1, -1), (-1, -1))
        enemyColor = 'b' if  self.whiteToMove else 'w'
        for d in directions:
            for i in range(1, 8):
                endRow = r + d[0] * i
                endCol = c + d[1] * i
                if 0 <= endRow < 8 and 0 <= endCol < 8:
                    endPiece = self.board[endRow][endCol]
                    if endPiece == '--':
                        moves.append(Move((r, c), (endRow, endCol), self.board))
                    elif endPiece[0] == enemyColor:
                        moves.append(Move((r, c), (endRow, endCol), self.board))
                        break
                    else:
                        break
                else:
                    break
            
    '''
    get all the Queen moves for the rook located at row , col and add these moves to the list
    '''
    def getQueenMoves(self, r, c, moves):
        self.getRookMoves(r, c, moves)
        self.getBishopMoves(r, c, moves)
        
            
    '''
    get all the rook moves for the rook located at row , col and add these moves to the list
    '''
    def getKingMoves(self, r, c, moves):
        directions = ((1, 0), (1, 1), (1, -1), (0, 1), (0, -1), (-1, 0), (-1, 1), (-1, -1))
        enemyColor = 'b' if self.whiteToMove else 'w'
        for i in range(8):
            endRow = r + directions[i][0]
            endCol = c + directions[i][1]
            if 0 <= endRow < 8 and 0 <= endCol < 8:
                endPiece = self.board[endRow][endCol]
                if endPiece[0] == enemyColor or endPiece == '--':
                    moves.append(Move((r, c), (endRow, endCol), self.board))
        
    
    '''
    Generate all vailid castle moves for the king at (r, c) and add them to the list of moves
    '''    
    def getCastleMoves(self, r, c, moves):
        if self.squareUnderAttack(r, c):
            return #can't castle while we in check
        if (self.whiteToMove and self.currentCastlingRight.wks) or (not self.whiteToMove and self.currentCastlingRight.bks):
            self.getKingsideCastleMoves(r, c, moves)
        if (self.whiteToMove and self.currentCastlingRight.wqs) or (not self.whiteToMove and self.currentCastlingRight.bqs):
            self.getQueensideCastleMoves(r, c, moves)
        
        
    def getKingsideCastleMoves(self, r, c, moves):
        if self.board[r][c+1] == '--' and self.board[r][c+2] == '--':
            if not self.squareUnderAttack(r, c+1) and not self.squareUnderAttack(r, c+2):
                moves.append(Move((r, c), (r, c+2), self.board, isCastleMove = True))
    
    # def getQueensideCastleMoves(self, r, c, moves):
    #     if self.board[r][c-1] == '--' and self.board[r][c-2] == '--' :
    #         if not self.squareUnderAttack(r, c-1) and not self.squareUnderAttack(r, c-2):
    #             moves.append(Move((r, c), (r, c-2), self.board, isCastleMove = True))
    def getQueensideCastleMoves(self, r, c, moves):
        # Check squares between king and rook are empty
        if self.board[r][c-1] == '--' and self.board[r][c-2] == '--' and self.board[r][c-3] == '--':
            # Check king does not pass through or land on attacked squares
            if not self.squareUnderAttack(r, c-1) and not self.squareUnderAttack(r, c-2):
                # Check rook is present at the correct square
                if (self.whiteToMove and self.board[r][c-4] == 'wR') or (not self.whiteToMove and self.board[r][c-4] == 'bR'):
                    moves.append(Move((r, c), (r, c-2), self.board, isCastleMove=True))
        
        
      
      
class CastleRight():
    def __init__(self, wks, bks, wqs, bqs):
        self.wks = wks
        self.bks = bks
        self.wqs = wqs
        self.bqs = bqs
        
                  
    
class Move():
    #map keys to values
    #key: value
    ranksToRows = {'1': 7, '2': 6, '3': 5, '4': 4, '5': 3, '6': 2, '7': 1, '8': 0}        
    rowsToRanks = {v: k for k, v in ranksToRows.items()}
    filesToCols = {'a': 0, 'b': 1, 'c': 2, 'd': 3, 'e': 4, 'f': 5, 'g': 6, 'h': 7}
    colsToFiles = {v: k for k, v in filesToCols.items()}
        
        
    def __init__(self, startSq, endSq, board, isenpassantmove=False, isCastleMove = False):
        self.startRow = startSq[0]
        self.startCol = startSq[1]
        self.endRow = endSq[0]
        self.endCol = endSq[1] 
        self.pieceMoved = board[self.startRow][self.startCol]
        self.pieceCaptured = board[self.endRow][self.endCol]
        #pawn promotion
        self.isPawnPromotion = (self.pieceMoved=='wp' and self.endRow ==0) or (self.pieceMoved == 'bp' and self.endRow == 7)
        #en passant
        self.isEnpassantMove = isenpassantmove
        if self.isEnpassantMove:
            self.pieceCaptured = 'wp' if self.pieceMoved == 'bp' else 'bp'
        #castle move
        self.isCastleMove = isCastleMove
            
            
        self.moveID = self.startRow * 1000 + self.startCol * 100 + self.endRow * 10 + self.endCol
        
        
        
    '''
    overwriting the equals method
    '''
    def __eq__(self, other):
        if isinstance(other, Move):
            return self.moveID == other.moveID
        return False
            
    def getChessNotation(self):
        return self.getRankFile(self.startRow, self.startCol) + self.getRankFile(self.endRow, self.endCol)
                
    def getRankFile(self,r,c):
        return self.colsToFiles[c] + self.rowsToRanks[r]
            
        
            
            
        
    
        