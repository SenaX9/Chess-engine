import pygame
from chessmain import main



class Button:
    def __init__(self, text, pos, size, callback):
        self.rect = pygame.Rect(pos, size)
        self.color = (29, 71, 34)
        self.hover_color = (139, 204, 147)
        self.text = text
        self.font = pygame.font.SysFont(None, 40)
        self.callback = callback

    def draw(self, surface):
        color = self.hover_color if self.rect.collidepoint(pygame.mouse.get_pos()) else self.color
        pygame.draw.rect(surface, color, self.rect, border_radius=20)
        surface.blit(self.font.render(self.text, True, (255, 255, 255)), self.font.render(self.text, True, (255, 255, 255)).get_rect(center=self.rect.center))

    def handle_event(self, event):
        if event.type == pygame.MOUSEBUTTONDOWN and self.rect.collidepoint(event.pos):
            self.callback()


class Screen:
    def __init__(self, game):
        self.game = game
    def handle_events(self, events):
        pass
    def update(self): 
        pass
    def draw(self, surface):
        pass


class MainMenu(Screen):
    def __init__(self, game):
        super().__init__(game)
        self.font = pygame.font.SysFont(None, 60)
        self.buttons = [
            Button("Play", (146, 200), (200, 50), lambda: start_chess_game(game)) ,
            Button("Options", (146, 270), (200, 50), lambda: game.change_screen(OptionsScreen)),
            Button("Exit", (146, 340), (200, 50), lambda: setattr(game, "running", False)),
        ]

    def handle_events(self, events):
        for event in events:
            if event.type == pygame.QUIT:
                self.game.running = False
            for button in self.buttons:
                button.handle_event(event)

    def draw(self, surface):
        surface.fill((61, 161, 66))
        surface.blit(self.font.render("Chess", True, (255, 255, 255)), (176, 100))
        for button in self.buttons:
            button.draw(surface)

class OptionsScreen(Screen):
    def __init__(self, game):
        super().__init__(game)
        self.buttons = [
            Button("History", (146, 150), (220, 50), lambda: game.change_screen(History)),
            Button("BoardColour", (146, 220), (220, 50), lambda: game.change_screen(BoardColourScreen)),
            Button("Back", (146, 290), (220, 50), lambda: game.change_screen(MainMenu)),
        ]

    def handle_events(self, events):
        for event in events:
            if event.type == pygame.QUIT:
                self.game.running = False
            for button in self.buttons:
                button.handle_event(event)

    def draw(self, surface):
        surface.fill((61, 161, 66))
        for button in self.buttons:
            button.draw(surface)
            

class BoardColourScreen(Screen):
    def __init__(self, game):
        super().__init__(game)
        self.buttons = [
            Button("Green", (146, 100), (220, 50), self.select_green),
            Button("Blue", (146, 170), (220, 50), self.select_blue),
            Button("Red", (146, 240), (220, 50), self.select_red),
            Button("Classic", (146, 310), (220, 50), self.select_classic),
            Button("Back", (146, 380), (220, 50), lambda: game.change_screen(OptionsScreen)),
        ]

    def select_green(self):
        self.game.selected_board_type = "Green"
        self.game.change_screen(OptionsScreen)

    def select_blue(self):
        self.game.selected_board_type = "Blue"
        self.game.change_screen(OptionsScreen)

    def select_red(self):
        self.game.selected_board_type = "Red"
        self.game.change_screen(OptionsScreen)

    def select_classic(self):
        self.game.selected_board_type = "Classic"
        self.game.change_screen(OptionsScreen)

    def handle_events(self, events):
        for event in events:
            if event.type == pygame.QUIT:
                self.game.running = False
            for button in self.buttons:
                button.handle_event(event)

    def draw(self, surface):
        surface.fill((61, 161, 66))
        for button in self.buttons:
            button.draw(surface)

    
class History(Screen):
    def __init__(self, game):
        super().__init__(game)
        self.font = pygame.font.SysFont(None, 30)
        try:
            with open("history.txt", "r") as file:
                self.text = file.read()
        except FileNotFoundError:
            self.text = "No game history yet."
        self.buttons = [
            Button("Back", (200, 400), (100, 40), lambda: game.change_screen(OptionsScreen))
        ]

    def handle_events(self, events):
        for event in events:
            if event.type == pygame.QUIT:
                self.game.running = False
            for button in self.buttons:
                button.handle_event(event)
    def draw(self, surface):
        surface.fill((200, 200, 200))
        y = 100
        for line in self.text.splitlines():
            surface.blit(self.font.render(line, True, (0, 0, 0)), (20, y))
            y += 30
        for button in self.buttons:
            button.draw(surface)

        
class Game:
    def __init__(self):
        pygame.init()
        self.screen = pygame.display.set_mode((512, 512))
        pygame.display.set_icon(pygame.image.load('chess/images-20250415T085406Z-001\images/wK.png'))
        pygame.display.set_caption("Menu")
        self.clock = pygame.time.Clock()
        self.running = True
        self.selected_board_type = "grey"
        self.change_screen(MainMenu)

    def change_screen(self, screen_class):
        self.current_screen = screen_class(self)

    def run(self):
        while self.running:
            events = pygame.event.get()
            self.current_screen.handle_events(events)
            self.current_screen.update()
            self.current_screen.draw(self.screen)
            pygame.display.flip()
            self.clock.tick(15)
        pygame.quit()
        
def start_chess_game(game):
    result = main(game.screen, game.selected_board_type)
    if result == "menu":
        game.change_screen(MainMenu)
        
    elif result == "quit":
        game.running = False
        
        
if __name__ == "__main__":
    game = Game()
    game.run()

        

        
       
       
        
        

